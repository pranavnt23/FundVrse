import React from 'react';
import { BrowserRouter as Router, Route, Routes, useNavigate, Link, useLocation } from 'react-router-dom';
import './App.css';
import logo from './images/FundLogo-removebg-preview.png';
import LoginComponent from './LoginComponent/LoginComponent';
import RegisterComponent from './RegisterComponent/RegisterComponent';
import AboutComponent from './AboutComponent/AboutComponent';
import ContactComponent from './ContactComponent/ContactComponent';
import FaqComponent from './FaqComponent/FaqComponent';
import Home from './Home';
import Footer from './FooterComponent/FooterComponent';

const Schemes = () => <div>Schemes Page Content</div>;

// ScrollToTop component to handle scroll position on route changes
const ScrollToTop = () => {
  const location = useLocation();
  
  React.useEffect(() => {
    // Reset scroll position when location changes
    window.scrollTo(0, 0);
  }, [location.pathname]); // Only trigger on pathname changes

  return null;
};

const Navigation = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleNavigation = (e, path) => {
    e.preventDefault();
    
    if (path === '/') {
      // Handle Home navigation
      navigate('/');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    else if (path === '/schemes' || path === '/login' || path === '/register') {
      // Direct navigation for separate pages
      navigate(path);
      window.scrollTo({ top: 0, behavior: 'instant' }); // Instant scroll for page changes
    } else {
      // For About, FAQ, and Contact sections
      if (location.pathname !== '/') {
        // If not on home page, navigate to home first
        navigate('/', { state: { scrollTo: path } });
      } else {
        // If on home page, just scroll
        const sectionId = path.replace('#', '');
        const element = document.getElementById(sectionId);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      }
    }
  };

  return (
    <header className="fundverse-header">
      <div className="logo-section">
        <img src={logo} alt="Fundverse logo" />
        <span className="fundverse-title">FUNDVERSE</span>
      </div>
      <nav className="main-nav">
        <Link to="/" onClick={(e) => handleNavigation(e, '/')}>HOME</Link>
        <Link to="#about-section" onClick={(e) => handleNavigation(e, '#about-section')}>ABOUT</Link>
        <Link to="/schemes" onClick={(e) => handleNavigation(e, '/schemes')}>SCHEMES</Link>
        <Link to="#faqs-section" onClick={(e) => handleNavigation(e, '#faqs-section')}>FAQs</Link>
        <Link to="#contact-section" onClick={(e) => handleNavigation(e, '#contact-section')}>CONTACT</Link>
      </nav>
      <div className="auth-section">
        <Link to="/login" onClick={(e) => handleNavigation(e, '/login')}>LOGIN</Link>
        <Link to="/register" onClick={(e) => handleNavigation(e, '/register')}>REGISTER</Link>
      </div>
    </header>
  );
};

function HomePage() {
  const location = useLocation();
  
  React.useEffect(() => {
    // Handle scrolling when navigating back to home page
    if (location.state?.scrollTo) {
      const sectionId = location.state.scrollTo.replace('#', '');
      const element = document.getElementById(sectionId);
      if (element) {
        setTimeout(() => {
          element.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      }
    }
  }, [location]);

  return (
    <>
      <section id="home-section">
        <Home />
      </section>
      <section id="about-section">
        <AboutComponent />
      </section>
      <section id="faqs-section">
        <FaqComponent />
      </section>
      <section id="contact-section">
        <ContactComponent />
      </section>
    </>
  );
}

function App() {
  return (
    <Router>
      <div className="App">
        <ScrollToTop /> {/* Add ScrollToTop component */}
        <Navigation />
        
        <Routes>
          {/* Home route with all scrollable sections */}
          <Route path="/" element={<HomePage />} />

          {/* Separate routes for standalone pages */}
          <Route path="/schemes" element={<Schemes />} />
          <Route path="/login" element={<LoginComponent />} />
          <Route path="/register" element={<RegisterComponent />} />
        </Routes>

        <Footer />
      </div>
    </Router>
  );
}

export default App;