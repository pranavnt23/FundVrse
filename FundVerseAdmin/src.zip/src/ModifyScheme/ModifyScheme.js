import React from 'react';

const ModifyScheme = () => {
  return <div><h2>Modify Scheme Page</h2></div>;
};

export default ModifyScheme;
