import React, { useState } from 'react';
import './DeleteScheme.css'; // Make sure to include the correct path to your CSS file

const Schemes = () => {
  const [schemes, setSchemes] = useState([
    {
      name: "Gold Savings Scheme",
      description: "Members contribute a fixed amount monthly to accumulate gold or cash equivalent at the end of the chit period.",
      targetAudience: "Individuals seeking stable, long-term savings in gold.",
      investmentPlan: [
        "Monthly Contribution: ₹10,000 to ₹50,000",
        "Chit Period: 12 months to 36 months",
        "Total Fund Value:",
        "12-month plan: ₹1.2 lakh to ₹6 lakh",
        "36-month plan: ₹3.6 lakh to ₹18 lakh",
      ],
      benefits: [
        "Redeemable in gold bars or coins, or in cash based on market rates.",
        "Option for early withdrawal or purchase from partnered jewelers at discounted rates.",
      ],
    },
    {
      name: "Diamond Wealth Plan",
      description: "A premium chit plan designed for those interested in high-value luxury investments, redeemable in diamonds or cash.",
      targetAudience: "High-net-worth individuals or luxury investors.",
      investmentPlan: [
        "Monthly Contribution: ₹50,000 to ₹2 lakh",
        "Chit Period: 12 months to 24 months",
        "Total Fund Value:",
        "12-month plan: ₹6 lakh to ₹24 lakh",
        "24-month plan: ₹12 lakh to ₹48 lakh",
      ],
      benefits: [
        "High-value rewards including exclusive diamond pieces or the equivalent cash value.",
        "Access to luxury brands and bespoke jewelry options.",
        "Special discounts with diamond merchants.",
      ],
    },
    {
      name: "Silver Harvest Scheme",
      description: "A more affordable chit plan for those looking to invest smaller amounts and save towards silver or cash rewards.",
      targetAudience: "Medium-income groups or small investors.",
      investmentPlan: [
        "Monthly Contribution: ₹2,000 to ₹10,000",
        "Chit Period: 12 months to 24 months",
        "Total Fund Value:",
        "12-month plan: ₹24,000 to ₹1.2 lakh",
        "24-month plan: ₹48,000 to ₹2.4 lakh",
      ],
      benefits: [
        "Redeemable for silver or cash with flexible redemption terms.",
        "Discounts or benefits with partnered silver dealers for jewelry or bullion purchases.",
      ],
    },
    {
      name: "Platinum Prestige Scheme",
      description: "A premium plan targeted at higher-income investors looking to diversify in platinum assets.",
      targetAudience: "Upper-middle-class individuals or those seeking unique investment options.",
      investmentPlan: [
        "Monthly Contribution: ₹25,000 to ₹1 lakh",
        "Chit Period: 18 months to 36 months",
        "Total Fund Value:",
        "18-month plan: ₹4.5 lakh to ₹18 lakh",
        "36-month plan: ₹9 lakh to ₹36 lakh",
      ],
      benefits: [
        "Redeemable in platinum bullion or jewelry, with a cash option available.",
        "Exclusive offers and partnerships with platinum dealers.",
        "Flexible withdrawal options after half the chit period.",
      ],
    },
    {
      name: "Education Savings Scheme",
      description: "This chit scheme is designed to help families save for higher education or other educational expenses.",
      targetAudience: "Parents or guardians planning for children’s education.",
      investmentPlan: [
        "Monthly Contribution: ₹5,000 to ₹20,000",
        "Chit Period: 12 months to 36 months",
        "Total Fund Value:",
        "12-month plan: ₹60,000 to ₹2.4 lakh",
        "36-month plan: ₹1.8 lakh to ₹7.2 lakh",
      ],
      benefits: [
        "Funds redeemable for education-related costs or as a lump sum payout.",
        "Partnerships with educational institutions or scholarship programs.",
      ],
    },
    {
      name: "Travel Dream Scheme",
      description: "A travel-focused chit fund designed for individuals or families who wish to save towards a dream vacation or travel-related expenses.",
      targetAudience: "Frequent travelers or families planning vacations.",
      investmentPlan: [
        "Monthly Contribution: ₹5,000 to ₹30,000",
        "Chit Period: 12 months to 24 months",
        "Total Fund Value:",
        "12-month plan: ₹60,000 to ₹3.6 lakh",
        "24-month plan: ₹1.2 lakh to ₹7.2 lakh",
      ],
      benefits: [
        "Redeemable for travel vouchers, holiday packages, or cash.",
        "Partnerships with travel agencies, airlines, or hotels for discounted bookings.",
        "Flexible plan adjustments for last-minute bookings or trip changes.",
      ],
    },
    {
      name: "Wedding Bliss Fund",
      description: "This scheme is designed to help families save towards wedding expenses, allowing them to accumulate a sizable amount for the big day.",
      targetAudience: "Families or couples planning weddings.",
      investmentPlan: [
        "Monthly Contribution: ₹10,000 to ₹1 lakh",
        "Chit Period: 12 months to 36 months",
        "Total Fund Value:",
        "12-month plan: ₹1.2 lakh to ₹12 lakh",
        "36-month plan: ₹3.6 lakh to ₹36 lakh",
      ],
      benefits: [
        "Redeemable in cash or in wedding services (venue, catering, photography, etc.).",
        "Partnerships with wedding vendors for discounted services.",
        "Early redemption options to assist in wedding planning.",
      ],
    },
    {
      name: "Tech Gadget Scheme",
      description: "A scheme that allows participants to save up for the latest technology gadgets, electronics, or devices.",
      targetAudience: "Tech enthusiasts or families looking to invest in technology upgrades.",
      investmentPlan: [
        "Monthly Contribution: ₹2,000 to ₹15,000",
        "Chit Period: 12 months to 18 months",
        "Total Fund Value:",
        "12-month plan: ₹24,000 to ₹1.8 lakh",
        "18-month plan: ₹36,000 to ₹2.7 lakh",
      ],
      benefits: [
        "Redeemable for popular gadgets like smartphones, laptops, or home electronics, or for cash.",
        "Special offers and tie-ups with electronics stores for additional discounts.",
        "Flexibility to swap products based on user preferences and market trends.",
      ],
    },
    {
      name: "Healthcare Savings Plan",
      description: "A scheme for individuals and families to save for medical emergencies or planned healthcare expenses.",
      targetAudience: "Health-conscious individuals or families planning for future medical costs.",
      investmentPlan: [
        "Monthly Contribution: ₹5,000 to ₹50,000",
        "Chit Period: 12 months to 36 months",
        "Total Fund Value:",
        "12-month plan: ₹60,000 to ₹6 lakh",
        "36-month plan: ₹1.8 lakh to ₹18 lakh",
      ],
      benefits: [
        "Redeemable for healthcare services (hospitalization, surgeries, checkups) or cash.",
        "Partnerships with hospitals, clinics, or insurance providers for discounts.",
        "Flexibility to use the funds for preventive healthcare or medical emergencies.",
      ],
    },
  ]);

  const handleDelete = (index) => {
    const updatedSchemes = schemes.filter((_, i) => i !== index);
    setSchemes(updatedSchemes);
  };

  return (
    <div className="schemes-container">
      {schemes.map((scheme, index) => (
        <div key={index} className="scheme-card">
          <h3>{scheme.name}</h3>
          <p>{scheme.description}</p>
          <h4>Target Audience: {scheme.targetAudience}</h4>
          <h4>Investment Plan:</h4>
          <ul>
            {scheme.investmentPlan.map((plan, i) => (
              <li key={i}>{plan}</li>
            ))}
          </ul>
          <h4>Benefits:</h4>
          <ul>
            {scheme.benefits.map((benefit, i) => (
              <li key={i}>{benefit}</li>
            ))}
          </ul>
          <button onClick={() => handleDelete(index)} className="delete-btn">Delete</button>
        </div>
      ))}
    </div>
  );
};

export default Schemes;
