import React from 'react';

const Auction = () => {
  return <div><h2>Auction Page</h2></div>;
};

export default Auction;
