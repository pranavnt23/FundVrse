import React, { useState } from 'react';
import './SearchBySchemes.css';

const SearchByScheme = () => {
  const [schemeName, setSchemeName] = useState('');
  const [customerDetails, setCustomerDetails] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Sample customer data
  const customers = [
    {
        username: 'user_23',
        fname: 'Pranav',
        lname: 'N T',
        phone_number: '9976334386',
        email: 'pranav39nt@gmail.com',
        aadharno: '5441723111211112',
        panno: 'hmfxgse',
        acc_num: '1234567890',
        ifsc_code: 'IFSC0001',
        bank_account_name: 'Pranav N T',
        schemes_registered: [
          {
            scheme_id: 'Scheme A',
            has_won_bid: true,
            won_bid_month: 'October',
          },
        ],
      },
      {
        username: 'user_45',
        fname: 'Aditi',
        lname: 'K S',
        phone_number: '9988776655',
        email: 'aditi@gmail.com',
        aadharno: '123456789012',
        panno: 'XYZABC1234',
        acc_num: '0987654321',
        ifsc_code: 'IFSC0002',
        bank_account_name: 'Aditi K S',
        schemes_registered: [
          {
            scheme_id: 'Scheme A',
            has_won_bid: false,
          },
        ],
      },
      // Add more customers as needed
  ];

  const handleSearch = () => {
    setLoading(true);
    const filteredCustomers = customers.filter(customer =>
      customer.schemes_registered.some(scheme => scheme.scheme_id === schemeName)
    );

    if (filteredCustomers.length > 0) {
      setCustomerDetails(filteredCustomers);
      setError('');
    } else {
      setCustomerDetails([]);
      setError('No customers found for the specified scheme. Try another one!');
    }
    setLoading(false);
  };

  const handleClear = () => {
    setSchemeName('');
    setCustomerDetails([]);
    setError('');
  };

  return (
    <div className="search-by-scheme-container">
      <h3>Search by Scheme</h3>
      <input
        type="text"
        placeholder="Enter scheme name..."
        value={schemeName}
        onChange={(e) => setSchemeName(e.target.value)}
        aria-label="Scheme Name"
      />
      <div className="button-container">
        <button onClick={handleSearch}>Search</button>
        <button onClick={handleClear} disabled={!schemeName}>Clear</button>
      </div>

      {loading && <p>Loading...</p>}
      {error && <p className="error-message">{error}</p>}

      {customerDetails.length > 0 && (
        <div className="table-responsive">
          <table className="customer-table">
            <thead>
              <tr>
                <th>S.No</th>
                <th>Username</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Phone No</th>
                <th>Email ID</th>
                <th>Aadhar No</th>
                <th>PAN No</th>
                <th>Acc. No</th>
                <th>IFSC Code</th>
                <th>Bank Account Name</th>
                <th>Won Bid</th>
                <th>Won Bid Month</th>
              </tr>
            </thead>
            <tbody>
              {customerDetails.map((customer, index) => {
                const wonBidInfo = customer.schemes_registered.find(scheme => scheme.scheme_id === schemeName);
                return (
                  <tr key={index}>
                    <td>{index + 1}</td>
                    <td>{customer.username}</td>
                    <td>{customer.fname}</td>
                    <td>{customer.lname}</td>
                    <td>{customer.phone_number}</td>
                    <td>{customer.email}</td>
                    <td>{customer.aadharno}</td>
                    <td>{customer.panno}</td>
                    <td>{customer.acc_num}</td>
                    <td>{customer.ifsc_code}</td>
                    <td>{customer.bank_account_name}</td>
                    <td>{wonBidInfo ? (wonBidInfo.has_won_bid ? 'Yes' : 'No') : 'No'}</td>
                    <td>{wonBidInfo && wonBidInfo.has_won_bid ? wonBidInfo.won_bid_month : 'N/A'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default SearchByScheme;
