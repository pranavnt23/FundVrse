import React, { useState } from 'react';
import './AddScheme.css'; // Link to the CSS file if needed

const AddScheme = () => {
  // State to hold form input values
  const [schemeDetails, setSchemeDetails] = useState({
    schemeName: '',
    description: '',
    targetAudience: '',
    monthlyContribution: '',
    chitPeriod: '',
    totalSlots: '',
    startDate: '',
    startTime: '',
    totalFundAmount: '' // Added state for total fund amount
  });

  const [showLogin, setShowLogin] = useState(false); // State to manage login dialog visibility
  const [adminCredentials, setAdminCredentials] = useState({
    username: '',
    password: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setSchemeDetails((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleAdminChange = (e) => {
    const { name, value } = e.target;
    setAdminCredentials((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setShowLogin(true); // Show login dialog when the form is submitted
  };

  const handleLoginSubmit = (e) => {
    e.preventDefault();
    // Here you can add your logic to verify the admin credentials
    const correctUsername = "admin";
    const correctPassword = "password";

    if (adminCredentials.username === correctUsername && adminCredentials.password === correctPassword) {
      console.log('Scheme Details Submitted:', schemeDetails);
      // Logic to add scheme goes here (e.g., API call)
      setShowLogin(false); // Close login dialog after successful login
      // Reset the form if needed
      setSchemeDetails({
        schemeName: '',
        description: '',
        targetAudience: '',
        monthlyContribution: '',
        chitPeriod: '',
        totalSlots: '',
        startDate: '',
        startTime: '',
        totalFundAmount: '' // Reset total fund amount
      });
      // Reset admin credentials
      setAdminCredentials({ username: '', password: '' });
    } else {
      alert('Invalid username or password!'); // Show error if credentials are incorrect
    }
  };

  return (
    <div className="add-scheme-container">
      <h2>Fill the Form to Add Schemes</h2>
      <form onSubmit={handleSubmit} className="add-scheme-form">
        {/* Scheme Name */}
        <label htmlFor="schemeName">Scheme Name:</label>
        <input
          type="text"
          id="schemeName"
          name="schemeName"
          value={schemeDetails.schemeName}
          onChange={handleChange}
          placeholder="Enter scheme name"
          required // Optional: Use this if you want to make the field required
        />

        {/* Scheme Description */}
        <label htmlFor="description">Description:</label>
        <textarea
          id="description"
          name="description"
          value={schemeDetails.description}
          onChange={handleChange}
          placeholder="Description of the scheme"
        />

        {/* Target Audience */}
        <label htmlFor="targetAudience">Target Audience:</label>
        <input
          type="text"
          id="targetAudience"
          name="targetAudience"
          value={schemeDetails.targetAudience}
          onChange={handleChange}
          placeholder="Individuals seeking stable, long-term savings in gold"
        />

        {/* Monthly Contribution */}
        <label htmlFor="monthlyContribution">Monthly Contribution (₹):</label>
        <input
          type="number"
          id="monthlyContribution"
          name="monthlyContribution"
          value={schemeDetails.monthlyContribution}
          onChange={handleChange}
          placeholder="Enter monthly contribution"
        />

        {/* Chit Period */}
        <label htmlFor="chitPeriod">Chit Period (months):</label>
        <input
          type="number"
          id="chitPeriod"
          name="chitPeriod"
          value={schemeDetails.chitPeriod}
          onChange={handleChange}
          placeholder="Enter chit period in months"
        />

        {/* Total Slots */}
        <label htmlFor="totalSlots">Total Slots:</label>
        <input
          type="number"
          id="totalSlots"
          name="totalSlots"
          value={schemeDetails.totalSlots}
          onChange={handleChange}
          placeholder="Enter total number of slots"
        />

        {/* Total Fund Amount */}
        <label htmlFor="totalFundAmount">Total Fund Amount (₹):</label>
        <input
          type="number"
          id="totalFundAmount"
          name="totalFundAmount"
          value={schemeDetails.totalFundAmount}
          onChange={handleChange}
          placeholder="Enter total fund amount"
        />

        {/* Start Date */}
        <label htmlFor="startDate">Starting Date of Bidding:</label>
        <input
          type="date"
          id="startDate"
          name="startDate"
          value={schemeDetails.startDate}
          onChange={handleChange}
        />

        {/* Start Time */}
        <label htmlFor="startTime">Starting Time of Bidding:</label>
        <input
          type="time"
          id="startTime"
          name="startTime"
          value={schemeDetails.startTime}
          onChange={handleChange}
        />

        {/* Submit Button */}
        <button type="submit">Add Scheme</button>
      </form>

      {/* Login Dialog */}
      {showLogin && (
        <div className="login-dialog-overlay">
          <div className="login-dialog">
            <h3>Admin Login</h3>
            <form onSubmit={handleLoginSubmit}>
              <label htmlFor="username">Username:</label>
              <input
                type="text"
                id="username"
                name="username"
                value={adminCredentials.username}
                onChange={handleAdminChange}
                required
              />
              <label htmlFor="password">Password:</label>
              <input
                type="password"
                id="password"
                name="password"
                value={adminCredentials.password}
                onChange={handleAdminChange}
                required
              />
              <button type="submit">Login to Add Scheme</button>
            </form>
            <button onClick={() => setShowLogin(false)}>Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AddScheme;
