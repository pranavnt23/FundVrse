import React from 'react';

const AuctionHistory = () => {
  return <div><h2>Auction History Page</h2></div>;
};

export default AuctionHistory;
